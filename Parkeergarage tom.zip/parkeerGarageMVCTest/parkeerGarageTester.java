package parkeerGarageMVCTest;

import parkeerGarageMVCTest.Model.parkeerGarageSimulator;

public class parkeerGarageTester {

	public static void main(String[] args) {

		parkeerGarageSimulator simulator = new parkeerGarageSimulator();
		simulator.run();
	}
}
